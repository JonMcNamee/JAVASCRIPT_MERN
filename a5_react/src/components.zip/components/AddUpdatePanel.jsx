export function AddUpdatePanel({ selectedItem, panelItem, inputChangeHandler, doneClickHandler, resetClickHandler, cancelClickHandler }) {
   /* return (
        <div className="add-update-panel">
          <h2>{selectedItem ? 'Update Item' : 'Add Item'}</h2>
    
          <form>
            <label>
              Category:
              <input
                type="text"
                name="category"
                value={panelItem.category}
                onChange={inputChangeHandler}
              />
            </label>
    
            <label>
              Description:
              <input
                type="text"
                name="description"
                value={panelItem.description}
                onChange={inputChangeHandler}
              />
            </label>
    
            <label>
              Price:
              <input
                type="number"
                name="price"
                value={panelItem.price}
                onChange={inputChangeHandler}
              />
            </label>
    
            <label>
              Vegetarian:
              <input
                type="checkbox"
                name="vegetarian"
                checked={panelItem.vegetarian}
                onChange={inputChangeHandler}
              />
            </label>
          </form>
    
          <div className="buttons">
            <button onClick={doneClickHandler}>
              {selectedItem ? 'Update' : 'Add'}
            </button>
    
            <button onClick={resetClickHandler}>Reset</button>
    
            <button onClick={cancelClickHandler}>Cancel</button>
          </div>
        </div>
   );*/
}